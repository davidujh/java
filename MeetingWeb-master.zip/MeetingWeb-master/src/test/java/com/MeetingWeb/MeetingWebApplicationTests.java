package com.MeetingWeb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MeetingWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
