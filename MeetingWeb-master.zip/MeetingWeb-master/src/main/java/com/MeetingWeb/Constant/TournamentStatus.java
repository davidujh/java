package com.MeetingWeb.Constant;

public enum TournamentStatus {
    UPCOMING ,RECRUITING, CLOSED ,IN_PROGRESS, COMPLETED
}
