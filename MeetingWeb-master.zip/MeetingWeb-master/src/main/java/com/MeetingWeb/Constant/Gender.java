package com.MeetingWeb.Constant;

public enum Gender {
    MALE,FEMALE,OTHER;
}
