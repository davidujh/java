package com.MeetingWeb.Constant;

public enum RegistType {
    FREE,APPROVAL
}
