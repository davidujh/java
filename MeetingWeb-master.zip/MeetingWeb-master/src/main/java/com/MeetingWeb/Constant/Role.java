package com.MeetingWeb.Constant;

public enum Role {
    USER, ADMIN, LEADER
}
