package com.MeetingWeb.Repository;

import com.MeetingWeb.Entity.UserSelectCategory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserSelectCategoryRepository extends JpaRepository<UserSelectCategory, Long> {
}
