package com.MeetingWeb.Dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TournamentSearchDto {
    private Long categoryId;
    private String inputText;
}
