package com.MeetingWeb.Excption;

public class ParticipantNotFoundException extends Throwable {
    public ParticipantNotFoundException(String message) {
        super(message);
    }
}
